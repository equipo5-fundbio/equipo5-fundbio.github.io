#ifndef KIVY_PANGOFT2_HEADER
#define KIVY_PANGOFT2_HEADER

// FreeType2 headers must be included via macros in ft2build.h
#include <ft2build.h>
#include FT_FREETYPE_H
#include FT_BITMAP_H

#endif
